'use strict';

var app = require('./lib');
exports.handler = app.lambda();
